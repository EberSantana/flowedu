#!/usr/bin/env node

/**
 * FlowEdu - Webhook para Deploy Automático
 * 
 * Este servidor escuta requisições HTTP e executa o deploy automaticamente
 * 
 * Instalação na VPS:
 * 1. npm install express
 * 2. node webhook-deploy.js
 * 3. Ou usar PM2: pm2 start webhook-deploy.js --name flowedu-webhook
 * 
 * Uso:
 * curl -X POST http://seu-servidor:3001/deploy \
 *   -H "Authorization: Bearer SEU_TOKEN_SECRETO"
 * 
 * Segurança:
 * - Configure um token secreto forte
 * - Use HTTPS em produção
 * - Configure firewall para limitar acesso
 */

const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.WEBHOOK_PORT || 3001;
const SECRET_TOKEN = process.env.WEBHOOK_SECRET || 'CHANGE_THIS_SECRET_TOKEN';
const PROJECT_DIR = process.env.PROJECT_DIR || '/root/flowedu';
const LOG_FILE = path.join(PROJECT_DIR, 'deploy-webhook.log');

// Middleware para parsing JSON
app.use(express.json());

// Função para logar
function log(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage.trim());
  fs.appendFileSync(LOG_FILE, logMessage);
}

// Função para executar comando
function executeCommand(command) {
  return new Promise((resolve, reject) => {
    exec(command, { cwd: PROJECT_DIR }, (error, stdout, stderr) => {
      if (error) {
        reject({ error, stderr });
      } else {
        resolve({ stdout, stderr });
      }
    });
  });
}

// Middleware de autenticação
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    log('❌ Tentativa de acesso sem autenticação');
    return res.status(401).json({ 
      success: false, 
      error: 'Authorization header missing' 
    });
  }
  
  const token = authHeader.replace('Bearer ', '');
  
  if (token !== SECRET_TOKEN) {
    log('❌ Tentativa de acesso com token inválido');
    return res.status(403).json({ 
      success: false, 
      error: 'Invalid token' 
    });
  }
  
  next();
}

// Health check (sem autenticação)
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'flowedu-webhook',
    timestamp: new Date().toISOString()
  });
});

// Endpoint de deploy (com autenticação)
app.post('/deploy', authenticate, async (req, res) => {
  const startTime = Date.now();
  log('🚀 Deploy iniciado via webhook');
  
  // Enviar resposta imediata
  res.json({ 
    success: true, 
    message: 'Deploy iniciado',
    timestamp: new Date().toISOString()
  });
  
  try {
    // Executar script de deploy
    log('📜 Executando script de deploy...');
    const { stdout, stderr } = await executeCommand('bash deploy.sh');
    
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    log(`✅ Deploy concluído com sucesso em ${duration}s`);
    log(`📊 Output: ${stdout}`);
    
    if (stderr) {
      log(`⚠️  Warnings: ${stderr}`);
    }
    
  } catch (err) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    log(`❌ Deploy falhou após ${duration}s`);
    log(`❌ Erro: ${err.error?.message || 'Unknown error'}`);
    log(`📊 Stderr: ${err.stderr}`);
  }
});

// Endpoint para ver logs (com autenticação)
app.get('/logs', authenticate, (req, res) => {
  const lines = parseInt(req.query.lines) || 50;
  
  try {
    const logContent = fs.readFileSync(LOG_FILE, 'utf8');
    const logLines = logContent.split('\n').filter(line => line.trim());
    const recentLogs = logLines.slice(-lines);
    
    res.json({
      success: true,
      logs: recentLogs,
      total: logLines.length
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: 'Could not read logs',
      message: err.message
    });
  }
});

// Endpoint para status do PM2 (com autenticação)
app.get('/status', authenticate, async (req, res) => {
  try {
    const { stdout } = await executeCommand('pm2 jlist');
    const processes = JSON.parse(stdout);
    const flowedu = processes.find(p => p.name === 'flowedu');
    
    if (flowedu) {
      res.json({
        success: true,
        status: flowedu.pm2_env.status,
        uptime: flowedu.pm2_env.pm_uptime,
        restarts: flowedu.pm2_env.restart_time,
        memory: flowedu.monit.memory,
        cpu: flowedu.monit.cpu
      });
    } else {
      res.json({
        success: false,
        error: 'FlowEdu process not found'
      });
    }
  } catch (err) {
    res.status(500).json({
      success: false,
      error: 'Could not get PM2 status',
      message: err.message
    });
  }
});

// Tratamento de erros
app.use((err, req, res, next) => {
  log(`❌ Erro no servidor: ${err.message}`);
  res.status(500).json({
    success: false,
    error: 'Internal server error'
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  log(`🎧 Webhook server listening on port ${PORT}`);
  log(`🔐 Secret token: ${SECRET_TOKEN.substring(0, 10)}...`);
  log(`📁 Project directory: ${PROJECT_DIR}`);
  log(`📜 Log file: ${LOG_FILE}`);
  log('');
  log('Endpoints disponíveis:');
  log('  GET  /health        - Health check (público)');
  log('  POST /deploy        - Executar deploy (autenticado)');
  log('  GET  /logs?lines=50 - Ver logs (autenticado)');
  log('  GET  /status        - Status PM2 (autenticado)');
  log('');
  log('⚠️  Configure o SECRET_TOKEN em produção!');
  log('   export WEBHOOK_SECRET="seu-token-super-secreto"');
  log('');
});

// Tratamento de sinais
process.on('SIGINT', () => {
  log('🛑 Webhook server stopped');
  process.exit(0);
});

process.on('SIGTERM', () => {
  log('🛑 Webhook server terminated');
  process.exit(0);
});
