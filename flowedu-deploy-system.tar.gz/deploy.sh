#!/bin/bash

# ============================================
# FlowEdu - Script de Deploy Automático
# ============================================
# 
# Este script automatiza o processo de deploy na VPS
# Uso: bash deploy.sh
#
# O que ele faz:
# 1. Faz backup do código atual
# 2. Puxa últimas mudanças do Git
# 3. Instala dependências
# 4. Faz build de produção
# 5. Reinicia o servidor PM2
# 6. Testa se está funcionando
# ============================================

set -e  # Para na primeira erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Diretório do projeto
PROJECT_DIR=~/flowedu
BACKUP_DIR=~/flowedu-backups

# Criar diretório de backups se não existir
mkdir -p $BACKUP_DIR

echo ""
log_info "==================================="
log_info "🚀 INICIANDO DEPLOY DO FLOWEDU"
log_info "==================================="
echo ""

# 1. Verificar se está no diretório correto
log_info "📁 Verificando diretório do projeto..."
if [ ! -d "$PROJECT_DIR" ]; then
    log_error "Diretório $PROJECT_DIR não encontrado!"
    exit 1
fi

cd $PROJECT_DIR
log_success "Diretório OK: $PROJECT_DIR"
echo ""

# 2. Fazer backup do código atual
log_info "💾 Fazendo backup do código atual..."
BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf $BACKUP_FILE \
    --exclude='node_modules' \
    --exclude='dist' \
    --exclude='.git' \
    client/ server/ drizzle/ shared/ package.json 2>/dev/null || true

if [ -f "$BACKUP_FILE" ]; then
    log_success "Backup criado: $BACKUP_FILE"
else
    log_warning "Não foi possível criar backup (continuando mesmo assim)"
fi
echo ""

# 3. Verificar se é repositório Git
log_info "🔍 Verificando repositório Git..."
if [ -d ".git" ]; then
    log_success "Repositório Git encontrado"
    
    # Verificar branch atual
    CURRENT_BRANCH=$(git branch --show-current)
    log_info "Branch atual: $CURRENT_BRANCH"
    
    # Salvar mudanças locais (se houver)
    if [[ -n $(git status -s) ]]; then
        log_warning "Há mudanças locais não commitadas"
        log_info "Salvando mudanças locais..."
        git stash
    fi
    
    # Puxar últimas mudanças
    log_info "📥 Puxando últimas mudanças do Git..."
    git pull origin $CURRENT_BRANCH
    log_success "Código atualizado do Git"
else
    log_warning "Não é um repositório Git (pulando git pull)"
fi
echo ""

# 4. Instalar/Atualizar dependências
log_info "📦 Instalando dependências..."
npm install --legacy-peer-deps
log_success "Dependências instaladas"
echo ""

# 5. Fazer build de produção
log_info "🔨 Fazendo build de produção..."
rm -rf dist/
npm run build

if [ $? -eq 0 ]; then
    log_success "Build concluído com sucesso!"
else
    log_error "Erro no build!"
    log_warning "Restaurando backup..."
    tar -xzf $BACKUP_FILE
    npm run build
    pm2 restart flowedu
    exit 1
fi
echo ""

# 6. Ajustar permissões
log_info "🔐 Ajustando permissões..."
chmod -R 755 dist/
log_success "Permissões ajustadas"
echo ""

# 7. Reiniciar PM2
log_info "🔄 Reiniciando servidor PM2..."
pm2 restart flowedu
sleep 3
log_success "Servidor reiniciado"
echo ""

# 8. Verificar status
log_info "📋 Verificando status..."
pm2 status flowedu
echo ""

# 9. Testar servidor
log_info "🧪 Testando servidor..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000)

if [ "$HTTP_CODE" = "200" ]; then
    log_success "Servidor respondendo! (HTTP $HTTP_CODE)"
else
    log_error "Servidor não está respondendo corretamente! (HTTP $HTTP_CODE)"
    log_warning "Verifique os logs: pm2 logs flowedu"
    exit 1
fi
echo ""

# 10. Limpar backups antigos (manter últimos 5)
log_info "🧹 Limpando backups antigos..."
cd $BACKUP_DIR
ls -t backup-*.tar.gz 2>/dev/null | tail -n +6 | xargs rm -f 2>/dev/null || true
BACKUP_COUNT=$(ls -1 backup-*.tar.gz 2>/dev/null | wc -l)
log_success "Backups mantidos: $BACKUP_COUNT"
echo ""

# 11. Resumo final
log_success "==================================="
log_success "🎉 DEPLOY CONCLUÍDO COM SUCESSO!"
log_success "==================================="
echo ""
log_info "📊 Resumo:"
log_info "  • Backup: $BACKUP_FILE"
log_info "  • Build: OK"
log_info "  • Servidor: Rodando"
log_info "  • Status: HTTP 200"
echo ""
log_info "🌐 Acesse: https://flowedu.app"
log_info "📜 Logs: pm2 logs flowedu"
log_info "📋 Status: pm2 status"
echo ""
log_warning "⚠️  IMPORTANTE: Limpe o cache do navegador!"
log_info "  Ctrl + Shift + Delete → Limpar cache"
log_info "  Ctrl + Shift + R → Force reload"
echo ""
