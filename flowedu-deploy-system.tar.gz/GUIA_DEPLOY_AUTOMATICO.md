# 🚀 Guia Completo: Deploy Automático do FlowEdu

Este guia explica como configurar e usar o sistema de deploy automático do FlowEdu.

---

## 📋 **Índice**

1. [Visão Geral](#visão-geral)
2. [Opção 1: Script de Deploy Manual](#opção-1-script-de-deploy-manual)
3. [Opção 2: GitHub Actions (Automático)](#opção-2-github-actions-automático)
4. [Opção 3: Webhook (Deploy via URL)](#opção-3-webhook-deploy-via-url)
5. [Comparação das Opções](#comparação-das-opções)
6. [Troubleshooting](#troubleshooting)

---

## 🎯 **Visão Geral**

O sistema de deploy automático oferece **3 formas** de atualizar o FlowEdu na VPS:

| Método | Quando Usar | Complexidade | Automação |
|--------|-------------|--------------|-----------|
| **Script Manual** | Deploy pontual, teste | Baixa | Manual |
| **GitHub Actions** | Deploy automático no push | Média | Automática |
| **Webhook** | Deploy via API/URL | Média | Semi-automática |

---

## 🔧 **Opção 1: Script de Deploy Manual**

### **O Que É?**

Um script Bash que você executa manualmente na VPS para fazer deploy.

### **Instalação**

**1. Copiar script para a VPS:**

```bash
# No seu computador, enviar arquivo
scp deploy.sh root@76.13.67.5:~/flowedu/

# Na VPS, dar permissão de execução
ssh root@76.13.67.5
cd ~/flowedu
chmod +x deploy.sh
```

**2. Testar:**

```bash
bash deploy.sh
```

### **O Que o Script Faz?**

1. ✅ Faz backup do código atual
2. ✅ Puxa últimas mudanças do Git (se configurado)
3. ✅ Instala dependências
4. ✅ Faz build de produção
5. ✅ Reinicia o servidor PM2
6. ✅ Testa se está funcionando
7. ✅ Limpa backups antigos (mantém últimos 5)

### **Uso**

```bash
# Conectar na VPS
ssh root@76.13.67.5

# Ir para o diretório do projeto
cd ~/flowedu

# Executar deploy
bash deploy.sh
```

### **Output Esperado**

```
ℹ️  ===================================
ℹ️  🚀 INICIANDO DEPLOY DO FLOWEDU
ℹ️  ===================================

✅ Diretório OK: /root/flowedu
✅ Backup criado: /root/flowedu-backups/backup-20260207-120000.tar.gz
✅ Código atualizado do Git
✅ Dependências instaladas
✅ Build concluído com sucesso!
✅ Permissões ajustadas
✅ Servidor reiniciado
✅ Servidor respondendo! (HTTP 200)

✅ ===================================
✅ 🎉 DEPLOY CONCLUÍDO COM SUCESSO!
✅ ===================================
```

### **Vantagens**

- ✅ Simples de usar
- ✅ Controle total
- ✅ Faz backup automático
- ✅ Rollback fácil em caso de erro

### **Desvantagens**

- ❌ Precisa acessar a VPS manualmente
- ❌ Não é automático

---

## 🤖 **Opção 2: GitHub Actions (Automático)**

### **O Que É?**

Deploy automático que roda **sempre que você faz push** para o GitHub.

### **Pré-requisitos**

1. Projeto no GitHub
2. Acesso SSH à VPS
3. GitHub Secrets configurados

### **Instalação**

**1. Criar arquivo de workflow:**

O arquivo `.github/workflows/deploy.yml` já foi criado. Você precisa fazer commit e push:

```bash
# No seu computador (diretório do projeto)
git add .github/workflows/deploy.yml
git add deploy.sh
git commit -m "feat: Adicionar deploy automático com GitHub Actions"
git push origin main
```

**2. Configurar Secrets no GitHub:**

Acesse: `https://github.com/seu-usuario/flowedu/settings/secrets/actions`

Adicione os seguintes secrets:

| Nome | Valor | Descrição |
|------|-------|-----------|
| `VPS_HOST` | `76.13.67.5` | IP da sua VPS |
| `VPS_USERNAME` | `root` | Usuário SSH |
| `VPS_SSH_KEY` | `[sua chave privada]` | Chave SSH privada |

**Como obter a chave SSH privada:**

```bash
# Na VPS, gerar chave SSH (se não tiver)
ssh-keygen -t rsa -b 4096 -C "github-actions"

# Ver a chave privada
cat ~/.ssh/id_rsa

# Copiar TODO o conteúdo (incluindo BEGIN e END)
```

**Adicionar chave pública ao authorized_keys:**

```bash
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
```

**3. Testar:**

Faça qualquer mudança no código e faça push:

```bash
git add .
git commit -m "test: Testar deploy automático"
git push origin main
```

Acesse: `https://github.com/seu-usuario/flowedu/actions`

Você verá o workflow rodando!

### **Como Funciona?**

1. Você faz push para o GitHub
2. GitHub Actions detecta o push
3. Workflow é executado:
   - Faz checkout do código
   - Instala Node.js
   - Instala dependências
   - Faz build
   - Conecta na VPS via SSH
   - Executa o script `deploy.sh`
4. Deploy concluído!

### **Vantagens**

- ✅ **Totalmente automático**
- ✅ Deploy em segundos após push
- ✅ Histórico de deploys no GitHub
- ✅ Notificações de sucesso/falha
- ✅ Pode executar manualmente

### **Desvantagens**

- ❌ Requer configuração inicial
- ❌ Depende do GitHub
- ❌ Consome minutos do GitHub Actions (grátis: 2000 min/mês)

### **Executar Manualmente**

Acesse: `https://github.com/seu-usuario/flowedu/actions`

1. Clique no workflow "Deploy to VPS"
2. Clique em "Run workflow"
3. Selecione a branch
4. Clique em "Run workflow"

---

## 🌐 **Opção 3: Webhook (Deploy via URL)**

### **O Que É?**

Um servidor que escuta requisições HTTP e executa o deploy automaticamente.

### **Instalação**

**1. Copiar arquivo para a VPS:**

```bash
# No seu computador
scp webhook-deploy.js root@76.13.67.5:~/flowedu/

# Na VPS
ssh root@76.13.67.5
cd ~/flowedu
```

**2. Gerar token secreto:**

```bash
# Gerar token aleatório
openssl rand -hex 32
# Exemplo: a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
```

**3. Configurar variáveis de ambiente:**

```bash
# Adicionar ao .bashrc ou .profile
echo 'export WEBHOOK_SECRET="seu-token-super-secreto-aqui"' >> ~/.bashrc
echo 'export WEBHOOK_PORT="3001"' >> ~/.bashrc
source ~/.bashrc
```

**4. Iniciar webhook com PM2:**

```bash
pm2 start webhook-deploy.js --name flowedu-webhook
pm2 save
```

**5. Verificar status:**

```bash
pm2 status flowedu-webhook
pm2 logs flowedu-webhook
```

**6. Liberar porta no firewall:**

```bash
sudo ufw allow 3001/tcp
```

### **Uso**

**1. Health Check (público):**

```bash
curl http://76.13.67.5:3001/health
```

**Resposta:**
```json
{
  "status": "ok",
  "service": "flowedu-webhook",
  "timestamp": "2026-02-07T15:00:00.000Z"
}
```

**2. Executar Deploy (autenticado):**

```bash
curl -X POST http://76.13.67.5:3001/deploy \
  -H "Authorization: Bearer seu-token-super-secreto-aqui"
```

**Resposta:**
```json
{
  "success": true,
  "message": "Deploy iniciado",
  "timestamp": "2026-02-07T15:00:00.000Z"
}
```

**3. Ver Logs (autenticado):**

```bash
curl http://76.13.67.5:3001/logs?lines=50 \
  -H "Authorization: Bearer seu-token-super-secreto-aqui"
```

**4. Ver Status PM2 (autenticado):**

```bash
curl http://76.13.67.5:3001/status \
  -H "Authorization: Bearer seu-token-super-secreto-aqui"
```

### **Integração com Serviços Externos**

**GitHub Webhook:**

1. Acesse: `https://github.com/seu-usuario/flowedu/settings/hooks`
2. Clique em "Add webhook"
3. Payload URL: `http://76.13.67.5:3001/deploy`
4. Content type: `application/json`
5. Secret: `seu-token-super-secreto-aqui`
6. Events: `Just the push event`
7. Clique em "Add webhook"

**Outros serviços:**

- **GitLab CI/CD:** Adicionar job que chama o webhook
- **Bitbucket Pipelines:** Adicionar step que chama o webhook
- **Cron Job:** Agendar deploy automático

### **Vantagens**

- ✅ Deploy via URL (fácil integrar)
- ✅ Funciona com qualquer serviço
- ✅ Logs centralizados
- ✅ API para status e logs

### **Desvantagens**

- ❌ Requer servidor adicional (PM2)
- ❌ Precisa configurar segurança (token)
- ❌ Expõe porta na VPS

---

## 📊 **Comparação das Opções**

| Característica | Script Manual | GitHub Actions | Webhook |
|----------------|---------------|----------------|---------|
| **Automação** | ❌ Manual | ✅ Automático | ⚠️ Semi-automático |
| **Complexidade** | 🟢 Baixa | 🟡 Média | 🟡 Média |
| **Requer Git** | ⚠️ Opcional | ✅ Sim | ❌ Não |
| **Requer GitHub** | ❌ Não | ✅ Sim | ❌ Não |
| **Backup Automático** | ✅ Sim | ✅ Sim | ✅ Sim |
| **Rollback** | ✅ Fácil | ⚠️ Manual | ⚠️ Manual |
| **Logs** | ⚠️ Terminal | ✅ GitHub | ✅ API |
| **Notificações** | ❌ Não | ✅ Sim | ⚠️ Custom |
| **Custo** | 🟢 Grátis | 🟢 Grátis* | 🟢 Grátis |

*GitHub Actions: 2000 minutos grátis/mês

---

## 🎯 **Recomendação**

### **Para Iniciantes:**
👉 **Script Manual** - Simples e eficaz

### **Para Projetos Profissionais:**
👉 **GitHub Actions** - Automático e confiável

### **Para Integração com Outros Serviços:**
👉 **Webhook** - Flexível e poderoso

### **Combinação Ideal:**
✅ **GitHub Actions** (deploy automático no push)  
✅ **Script Manual** (backup para deploy manual)  
✅ **Webhook** (opcional, para integrações)

---

## 🔧 **Troubleshooting**

### **Script Manual**

**Problema:** `Permission denied`

**Solução:**
```bash
chmod +x deploy.sh
```

**Problema:** `git pull failed`

**Solução:**
```bash
cd ~/flowedu
git status
git stash  # Se houver mudanças locais
git pull origin main
```

**Problema:** `Build failed`

**Solução:**
```bash
# Ver logs completos
npm run build 2>&1 | tee build.log
cat build.log

# Restaurar backup
cd ~/flowedu-backups
ls -lt  # Ver backups disponíveis
tar -xzf backup-YYYYMMDD-HHMMSS.tar.gz -C ~/flowedu
```

---

### **GitHub Actions**

**Problema:** `SSH connection failed`

**Solução:**
1. Verificar se a chave SSH está correta no GitHub Secrets
2. Testar conexão SSH manualmente:
```bash
ssh -i ~/.ssh/id_rsa root@76.13.67.5
```

**Problema:** `Workflow not running`

**Solução:**
1. Verificar se o arquivo está em `.github/workflows/deploy.yml`
2. Verificar se fez push do arquivo
3. Verificar permissões no GitHub

**Problema:** `Build failed in GitHub Actions`

**Solução:**
1. Ver logs no GitHub Actions
2. Testar build localmente:
```bash
npm install --legacy-peer-deps
npm run build
```

---

### **Webhook**

**Problema:** `Connection refused`

**Solução:**
```bash
# Verificar se webhook está rodando
pm2 status flowedu-webhook

# Verificar porta
sudo netstat -tlnp | grep 3001

# Verificar firewall
sudo ufw status
sudo ufw allow 3001/tcp
```

**Problema:** `401 Unauthorized`

**Solução:**
```bash
# Verificar token
echo $WEBHOOK_SECRET

# Se vazio, configurar
export WEBHOOK_SECRET="seu-token-aqui"
pm2 restart flowedu-webhook
```

**Problema:** `Deploy not executing`

**Solução:**
```bash
# Ver logs do webhook
pm2 logs flowedu-webhook

# Ver logs de deploy
cat ~/flowedu/deploy-webhook.log
```

---

## 📚 **Recursos Adicionais**

### **Documentação**

- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [PM2 Docs](https://pm2.keymetrics.io/docs/usage/quick-start/)
- [Express.js Docs](https://expressjs.com/)

### **Arquivos Criados**

- `deploy.sh` - Script de deploy manual
- `.github/workflows/deploy.yml` - GitHub Actions workflow
- `webhook-deploy.js` - Servidor webhook

### **Comandos Úteis**

```bash
# Ver status de todos os serviços
pm2 status

# Ver logs
pm2 logs flowedu
pm2 logs flowedu-webhook

# Reiniciar serviços
pm2 restart flowedu
pm2 restart flowedu-webhook

# Ver backups
ls -lh ~/flowedu-backups/

# Restaurar backup
cd ~/flowedu
tar -xzf ~/flowedu-backups/backup-YYYYMMDD-HHMMSS.tar.gz
npm run build
pm2 restart flowedu
```

---

## ✅ **Checklist de Configuração**

### **Script Manual**

- [ ] Copiar `deploy.sh` para VPS
- [ ] Dar permissão de execução (`chmod +x`)
- [ ] Testar execução
- [ ] Verificar backup criado

### **GitHub Actions**

- [ ] Criar arquivo `.github/workflows/deploy.yml`
- [ ] Fazer commit e push
- [ ] Configurar secrets no GitHub:
  - [ ] `VPS_HOST`
  - [ ] `VPS_USERNAME`
  - [ ] `VPS_SSH_KEY`
- [ ] Testar workflow manualmente
- [ ] Fazer push e verificar deploy automático

### **Webhook**

- [ ] Copiar `webhook-deploy.js` para VPS
- [ ] Gerar token secreto
- [ ] Configurar variáveis de ambiente
- [ ] Iniciar com PM2
- [ ] Liberar porta no firewall
- [ ] Testar health check
- [ ] Testar deploy via curl
- [ ] (Opcional) Configurar GitHub webhook

---

## 🎉 **Conclusão**

Agora você tem **3 formas** de fazer deploy do FlowEdu:

1. ✅ **Manual** - Rápido e simples
2. ✅ **Automático** - Push e pronto
3. ✅ **API** - Flexível e integrável

Escolha a que melhor se adapta ao seu workflow!

---

**Dúvidas?** Consulte a seção [Troubleshooting](#troubleshooting) ou os logs dos serviços.

**Sugestões?** Abra uma issue no GitHub ou entre em contato.

---

**Última atualização:** 07/02/2026  
**Versão:** 1.0.0
