import { useAuth } from "@/_core/hooks/useAuth";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Users, Shield, Mail, Calendar, AlertCircle, ArrowLeft, Trash2, RefreshCw, Eye, EyeOff, Search, X } from "lucide-react";
import { AdvancedPagination, usePagination } from "@/components/ui/advanced-pagination";
import { SearchFilter } from "@/components/ui/advanced-filters";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useLocation, Link } from "wouter";
import { getLoginUrl } from "@/const";
import Sidebar from "@/components/Sidebar";
import PageWrapper from "@/components/PageWrapper";

export default function AdminUsers() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  const [showInactive, setShowInactive] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState<"all" | "admin" | "user">("all");
  
  // Estado do formulário de cadastro
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUserName, setNewUserName] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [newUserRole, setNewUserRole] = useState<"admin" | "user">("user");
  
  const { data: activeUsers, isLoading: activeLoading, refetch: refetchActive } = trpc.admin.listActiveUsers.useQuery();
  const { data: inactiveUsers, isLoading: inactiveLoading, refetch: refetchInactive } = trpc.admin.listInactiveUsers.useQuery();
  const { data: pendingUsers, isLoading: pendingLoading, refetch: refetchPending } = trpc.admin.listPendingUsers.useQuery();
  
  const [viewMode, setViewMode] = useState<'active' | 'inactive' | 'pending'>('active');
  
  const baseUsers = viewMode === 'pending' ? pendingUsers : (viewMode === 'inactive' ? inactiveUsers : activeUsers);
  const usersLoading = viewMode === 'pending' ? pendingLoading : (viewMode === 'inactive' ? inactiveLoading : activeLoading);
  
  // Aplicar filtros
  const filteredUsers = useMemo(() => {
    let result = baseUsers || [];
    
    // Filtro de busca
    if (searchTerm) {
      result = result.filter((u) => 
        u.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.email?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filtro de papel
    if (roleFilter !== "all") {
      result = result.filter((u) => u.role === roleFilter);
    }
    
    return result;
  }, [baseUsers, searchTerm, roleFilter]);
  
  // Paginação
  const {
    currentPage,
    totalPages,
    totalItems,
    itemsPerPage,
    paginatedItems: allUsers,
    onPageChange,
    onItemsPerPageChange,
  } = usePagination(filteredUsers, 10);
  
  const refetch = () => {
    refetchActive();
    refetchInactive();
    refetchPending();
  };

  const approveUserMutation = trpc.admin.approveUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário aprovado com sucesso!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const rejectUserMutation = trpc.admin.rejectUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário rejeitado com sucesso!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateRoleMutation = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      toast.success("Papel do usuário atualizado com sucesso!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const deleteUserMutation = trpc.admin.deleteUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário desativado com sucesso!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const reactivateUserMutation = trpc.admin.reactivateUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário reativado com sucesso!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const createUserMutation = trpc.admin.createUser.useMutation({
    onSuccess: (data) => {
      toast.success(`Usuário ${data.user.name} criado com sucesso!`);
      // Limpar formulário
      setNewUserName("");
      setNewUserEmail("");
      setNewUserPassword("");
      setNewUserRole("user");
      setShowCreateForm(false);
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const permanentDeleteMutation = trpc.admin.permanentDeleteUser.useMutation({
    onSuccess: () => {
      toast.success("Usuário deletado permanentemente!");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  // Função para gerar senha aleatória
  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    let password = '';
    for (let i = 0; i < 8; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setNewUserPassword(password);
    setShowPassword(true);
    toast.info("Senha gerada! Anote para informar ao usuário.");
  };

  if (isLoading || usersLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Restrito</CardTitle>
            <CardDescription>Você precisa estar logado</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = getLoginUrl()} className="w-full">
              Fazer Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2 text-red-600">
              <AlertCircle className="w-6 h-6" />
              <CardTitle>Acesso Negado</CardTitle>
            </div>
            <CardDescription>Apenas administradores podem acessar esta página</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/")} className="w-full">
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleRoleChange = (userId: number, newRole: "admin" | "user") => {
    updateRoleMutation.mutate({ userId, role: newRole });
  };

  return (
    <>
      <Sidebar />
      <PageWrapper className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 p-6">
        <div className="container max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-slate-800 mb-2 flex items-center gap-3">
                  <Users className="w-10 h-10 text-purple-600" />
                  Gerenciamento de Usuários
                </h1>
                <p className="text-slate-600">Administre contas e permissões do sistema</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'active' ? 'default' : 'outline'}
                  onClick={() => setViewMode('active')}
                  className="flex items-center gap-2"
                >
                  <Eye className="w-4 h-4" />
                  Ativos
                </Button>
                <Button
                  variant={viewMode === 'pending' ? 'default' : 'outline'}
                  onClick={() => setViewMode('pending')}
                  className="flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4" />
                  Pendentes {pendingUsers && pendingUsers.length > 0 && `(${pendingUsers.length})`}
                </Button>
                <Button
                  variant={viewMode === 'inactive' ? 'default' : 'outline'}
                  onClick={() => setViewMode('inactive')}
                  className="flex items-center gap-2"
                >
                  <EyeOff className="w-4 h-4" />
                  Inativos
                </Button>
              </div>
            

            <Button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="bg-success hover:bg-success/90 text-white"
            >
              <Users className="w-4 h-4 mr-2" />
              {showCreateForm ? "Cancelar" : "Novo Usuário"}
            </Button>
          </div>
        </div>
        
        {/* Formulário de Cadastro */}
        {showCreateForm && (
          <Card className="mb-8 border-success/30 bg-success/10">
            <CardHeader>
              <CardTitle className="text-success">Cadastrar Novo Usuário</CardTitle>
              <CardDescription>Preencha os dados para criar um novo professor ou administrador. A senha será definida por você e deve ser informada ao usuário.</CardDescription>
            </CardHeader>
            <CardContent>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newUserName || !newUserEmail || !newUserPassword) {
                    toast.error("Preencha todos os campos obrigatórios");
                    return;
                  }
                  if (newUserPassword.length < 6) {
                    toast.error("A senha deve ter pelo menos 6 caracteres");
                    return;
                  }
                  createUserMutation.mutate({
                    name: newUserName,
                    email: newUserEmail,
                    password: newUserPassword,
                    role: newUserRole,
                  });
                }}
                className="space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Nome Completo *</label>
                    <input
                      type="text"
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                      placeholder="Ex: João Silva"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">E-mail *</label>
                    <input
                      type="email"
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                      placeholder="Ex: joao@email.com"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Senha Inicial *</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <input
                          type={showPassword ? "text" : "password"}
                          value={newUserPassword}
                          onChange={(e) => setNewUserPassword(e.target.value)}
                          placeholder="Mínimo 6 caracteres"
                          className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 pr-10"
                          required
                          minLength={6}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-700"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={generateRandomPassword}
                        className="whitespace-nowrap"
                      >
                        Gerar Senha
                      </Button>
                    </div>
                    <p className="text-xs text-slate-500">Anote a senha para informar ao usuário. Ele poderá alterá-la depois.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">Papel *</label>
                    <Select value={newUserRole} onValueChange={(value: "admin" | "user") => setNewUserRole(value)}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">Professor</SelectItem>
                        <SelectItem value="admin">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="flex justify-end gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowCreateForm(false);
                      setNewUserName("");
                      setNewUserEmail("");
                      setNewUserPassword("");
                      setNewUserRole("user");
                    }}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="bg-success hover:bg-success/90"
                    disabled={createUserMutation.isPending}
                  >
                    {createUserMutation.isPending ? "Criando..." : "Criar Usuário"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Usuários Ativos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-success">{activeUsers?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Usuários Inativos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-600">{inactiveUsers?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Administradores</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">
                {activeUsers?.filter((u) => u.role === "admin").length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600">Professores</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">
                {activeUsers?.filter((u) => u.role === "user").length || 0}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabela de Usuários */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Todos os Usuários</CardTitle>
                <CardDescription>Visualize e gerencie todos os usuários cadastrados</CardDescription>
              </div>
              <div className="text-sm text-slate-600">
                {allUsers?.length || 0} usuário(s) encontrado(s)
              </div>
            </div>
            
            {/* Filtros */}
            <div className="flex gap-4 mt-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Buscar por nome ou e-mail..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <Select value={roleFilter} onValueChange={(value: any) => setRoleFilter(value)}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por papel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os papéis</SelectItem>
                  <SelectItem value="admin">Administradores</SelectItem>
                  <SelectItem value="user">Professores</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>E-mail</TableHead>
                  <TableHead>Método de Login</TableHead>
                  <TableHead>Papel</TableHead>
                  <TableHead>Cadastrado em</TableHead>
                  <TableHead>Último Acesso</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {allUsers?.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-sm">
                          {u.name?.charAt(0).toUpperCase() || "?"}
                        </div>
                        {u.name || "Sem nome"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-slate-400" />
                        {u.email || "Não informado"}
                      </div>
                    </TableCell>
                    <TableCell>{u.loginMethod || "N/A"}</TableCell>
                    <TableCell>
                      {u.id === user.id ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          {u.role === "admin" ? "Administrador" : "Professor"} (Você)
                        </span>
                      ) : (
                        <Select
                          value={u.role}
                          onValueChange={(value) => handleRoleChange(u.id, value as "admin" | "user")}
                          disabled={updateRoleMutation.isPending}
                        >
                          <SelectTrigger className="w-[140px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user">Professor</SelectItem>
                            <SelectItem value="admin">Administrador</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Calendar className="w-4 h-4" />
                        {new Date(u.createdAt).toLocaleDateString("pt-BR")}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-slate-600">
                        {new Date(u.lastSignedIn).toLocaleDateString("pt-BR")}
                      </div>
                    </TableCell>
                    <TableCell>
                      {u.id !== user.id && (
                        <div className="flex gap-2">
                          {viewMode === 'pending' ? (
                            <>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  if (confirm(`Tem certeza que deseja APROVAR o usuário ${u.name}?`)) {
                                    approveUserMutation.mutate({ userId: u.id });
                                  }
                                }}
                                disabled={approveUserMutation.isPending}
                                className="text-green-600 hover:text-green-700 hover:bg-green-50"
                              >
                                <RefreshCw className="w-4 h-4 mr-1" />
                                Aprovar
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  if (confirm(`Tem certeza que deseja REJEITAR o cadastro de ${u.name}?`)) {
                                    rejectUserMutation.mutate({ userId: u.id });
                                  }
                                }}
                                disabled={rejectUserMutation.isPending}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <X className="w-4 h-4 mr-1" />
                                Rejeitar
                              </Button>
                            </>
                          ) : viewMode === 'inactive' ? (
                            <>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  if (confirm(`Tem certeza que deseja reativar o usuário ${u.name}?`)) {
                                    reactivateUserMutation.mutate({ userId: u.id });
                                  }
                                }}
                                disabled={reactivateUserMutation.isPending}
                                className="text-success hover:text-success/90 hover:bg-success/10"
                              >
                                <RefreshCw className="w-4 h-4 mr-1" />
                                Reativar
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  const confirmed = confirm(`⚠️ ATENÇÃO: Deletar Permanentemente\n\nTem certeza que deseja deletar PERMANENTEMENTE o usuário ${u.name}?\n\nEsta ação é IRREVERSÍVEL e irá:\n- Remover o usuário do sistema\n- Apagar todos os dados associados\n- Não poderá ser desfeita\n\nDigite SIM para confirmar.`);
                                  if (confirmed) {
                                    const doubleConfirm = prompt('Digite "DELETAR" em maiúsculas para confirmar a deleção permanente:');
                                    if (doubleConfirm === 'DELETAR') {
                                      permanentDeleteMutation.mutate({ userId: u.id });
                                    } else {
                                      toast.error('Deleção cancelada: confirmação incorreta');
                                    }
                                  }
                                }}
                                disabled={permanentDeleteMutation.isPending}
                                className="text-red-800 hover:text-red-900 hover:bg-red-100 border-red-300"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                Deletar Permanentemente
                              </Button>
                            </>
                          ) : (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                if (confirm(`Tem certeza que deseja desativar o usuário ${u.name}? O usuário não poderá mais fazer login, mas seus dados serão preservados.`)) {
                                  deleteUserMutation.mutate({ userId: u.id });
                                }
                              }}
                              disabled={deleteUserMutation.isPending}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4 mr-1" />
                              Desativar
                            </Button>
                          )}
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {/* Paginação */}
            <AdvancedPagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={totalItems}
              itemsPerPage={itemsPerPage}
              onPageChange={onPageChange}
              onItemsPerPageChange={onItemsPerPageChange}
              showItemsPerPage={true}
              showTotalItems={true}
              itemsPerPageOptions={[5, 10, 20, 50]}
            />
          </CardContent>
        </Card>
        </div>
      </PageWrapper>
    </>
  );
}
