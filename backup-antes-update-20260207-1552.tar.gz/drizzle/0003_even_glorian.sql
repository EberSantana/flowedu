ALTER TABLE `subjects` ADD `courseObjectives` text;--> statement-breakpoint
ALTER TABLE `subjects` ADD `courseContent` text;--> statement-breakpoint
ALTER TABLE `subjects` ADD `methodology` text;--> statement-breakpoint
ALTER TABLE `subjects` ADD `evaluation` text;--> statement-breakpoint
ALTER TABLE `subjects` ADD `bibliography` text;--> statement-breakpoint
ALTER TABLE `subjects` ADD `coursePlanPdfUrl` text;