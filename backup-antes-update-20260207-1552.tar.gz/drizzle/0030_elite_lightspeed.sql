ALTER TABLE `students` ADD `hd2dCharacterId` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `hd2dUnlockedCharacters` text DEFAULT ('[1]');