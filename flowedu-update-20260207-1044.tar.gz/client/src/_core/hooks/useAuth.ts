/**
 * @deprecated Use o hook de @/hooks/useAuth em vez deste
 * Este arquivo existe apenas para compatibilidade com código legado
 */
export { useAuth, getLoginUrl } from "@/hooks/useAuth";
